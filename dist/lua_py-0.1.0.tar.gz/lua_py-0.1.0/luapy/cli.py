def main():
    print("Hello, World!")