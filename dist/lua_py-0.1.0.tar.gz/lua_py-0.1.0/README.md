# lua.py
 
lua.py is a test module that allows lua to be executed in python.

.. Okay, well maybe not.
Anyway, lua.py is just a module that gets the roblox api easily.
(i know this is a bad name, but whatever, no one cares.)

Also, this is my first module. I am learning this from Carberra on YouTube. Here is the link: https://www.youtube.com/watch?v=WGsMydFFPMk