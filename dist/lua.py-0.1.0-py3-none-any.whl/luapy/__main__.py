if __name__ == "__main__":
    print("Loaded lua.py")